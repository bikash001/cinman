import socket
import subprocess
import json as simplejson
import requests

filein = subprocess.call("who >tmpfile",shell = True,stdout = subprocess.PIPE)
file = open("tmpfile","r")
data = file.read()
data = data.split(" ")
file.close()

print("user id : " + data[0])

textmesg = input("Enter your message :")

while True :
	if textmesg == "" :
		textmesg = input("Please re-enter your message :")
	else :
		break

class NetworkDetails:
	def __init__(self) :
		self.ip_addr = ""
		self.mac_addr = ""

	def getDetails(self):
		try :
			filein = subprocess.call("/sbin/ifconfig >networkdetails",shell = True , stdout = subprocess.PIPE)
			file = open("networkdetails","r")
			details = file.read()
			file.close()
			arr = details.split('\n\n')
			index = arr[0].find("inet addr")
			if index == -1:
				details = arr[2]
			else:
				details = arr[0]
			tmp = details.find("inet addr")
			tmp = tmp + len("inet addr") + 1
			while(details[tmp] != " ") :
				self.ip_addr += details[tmp]
				tmp = tmp + 1
			tmp = details.find("HWaddr")
			tmp = tmp + len("HWaddr") + 1
			while(details[tmp] != " ") :
				self.mac_addr += details[tmp]
				tmp = tmp + 1
		except :
			print("Error occured while gathering Network details")
		return 

	def getDictionary(self):
		tmpdict = {"mac_address" : self.mac_addr}
		return tmpdict 


net = NetworkDetails()
net.getDetails()

message = {"user" : data[0] , "content" : textmesg, "mac":net.getDictionary()['mac_address']}
# print message
message = simplejson.dumps(message)
url='http://127.0.0.1:8000/postmessage'#change url address here
r = requests.post(url, data=message)

# Response, status etc
r.text
r.status_code
filein = subprocess.call("rm tmpfile",shell = True)

