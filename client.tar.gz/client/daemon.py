import cinmantest
import log
import time
import json as simplejson
import requests
 
while True :
	url1 = 'http://10.21.238.199:8000/postdata'
	client_data = simplejson.dumps(cinmantest.client_data)
	r = requests.post(url1, data=client_data)
	r.text
	r.status_code
	url2 = 'http://10.21.238.199:8000/postlogs'
	logsdata = simplejson.dumps(log.logsdata)
	r = requests.post(url2, data=logsdata)
	r.text
	r.status_code
	time.sleep(60)
