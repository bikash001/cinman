import cinmantest
import log
import time
import json as simplejson
import requests

# change this address to the addres of the server
url = 'http://127.0.0.1:8000/'

while True :
	client_data = simplejson.dumps(cinmantest.client_data)
	r = requests.post(url+'postdata', data=client_data)
	r.text
	r.status_code
	logsdata = simplejson.dumps(log.logsdata)
	r = requests.post(url+'postlogs', data=logsdata)
	r.text
	r.status_code
	time.sleep(60)
