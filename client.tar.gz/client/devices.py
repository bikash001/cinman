import thread
import time
import os
import subprocess
import time
import json as simplejson
import requests

serveraddress='10.42.0.76:8000'

filein = subprocess.call("who >tmpfile",shell = True,stdout = subprocess.PIPE)

with file("tmpfile","r") as usern:
	user = usern.read()
	user = user.split(" ")[0]
	usern.close()

# Define a function for the thread
class NetworkDetails:
	def __init__(self) :
		self.ip_addr = ""
		self.mac_addr = ""

	def getDetails(self):
		try :
			filein = subprocess.call("/sbin/ifconfig eth0 >networkdetails",shell = True , stdout = subprocess.PIPE)
			with file("networkdetails","r") as netf:
				details = netf.read()
				tmp = details.find("inet addr")
				tmp = tmp + len("inet addr") + 1
				while(details[tmp] != " ") :
					self.ip_addr += details[tmp]
					tmp = tmp + 1
				tmp = details.find("HWaddr")
				tmp = tmp + len("HWaddr") + 1
				while(details[tmp] != " ") :
					self.mac_addr += details[tmp]
					tmp = tmp + 1
		except :
			print("Error occured while gathering Network details")
		return 

	def getDictionary(self):
		tmpdict = {"mac_address" : self.mac_addr}
		return tmpdict 


net = NetworkDetails()
net.getDetails()
mac=net.getDictionary()["mac_address"]

def print_time( threadName, delay):
	filein = subprocess.call("tail -n100 -f /var/log/syslog > out.txt", shell = True , stdout = subprocess.PIPE)

# Create two threads as follows
try:
    thread.start_new_thread( print_time, ("Thread-1", 2, ) )
except:
	print "Error: unable to start thread"

def find_between( s, first, last ):
	try:
	    start = s.index( first ) + len( first )
	    end = s.index( last, start )
	    return s[start:end]
	except ValueError:
	    return ""

while 1:
	pass
	filein = subprocess.call("tail -n +1 /var/log/syslog > output.txt", shell = True , stdout = subprocess.PIPE)
	#command="/var/log/syslog"
	#proc = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=None, shell=True)
	#op=proc.communicate()
	res={}
	with file("output.txt") as f:
			s = f.read()
	#print len(s)
	i=1
	x=[]
	#print s.count("New USB device found")
	#print s.count("new full-speed USB device number 4 using xhci_hcd")
	mydict={}
	while ("New USB device found" in s):
			#print "yes"
			i=i+1
			z=s
			#print s.find("New USB device found") 
			if(s[:s.find("New USB device found")].rfind("new")==-1):
				s=s[s.find("New USB device found")+40:]
				continue
			s=s[s[:s.find("New USB device found")].rfind("new"):]
			x.append(["connected",find_between(s,"Vendor=",","),find_between(s,"idProduct=","\n"),find_between(s,"Product: ","\n"),find_between(s,"New "," found"),find_between(s,"device number "," ")])
			res[find_between(s,"device number "," ")]=["connected",find_between(s,"Vendor=",","),find_between(s,"idProduct=","\n"),find_between(s,"Product: ","\n"),find_between(s,"New "," found")]
			s=s[s.find("New USB device found")+40:]
			#print "count = ",s.count("New USB device found")
			#print s[0:1000]
			#print x[len(x)-1]
			#print res
			#print len(s)," mini 1"
	f.close()
	with file("output.txt") as f:
			s = f.read()
	while ("disconnect," in s):
			z=s
			s=s[s.find("disconnect,")+11:]
			#print s[0:3000]		
			#x.append(["disconnected at "+z[:15],find_between(s,"device number ","\n")])
			#res[find_between(s,"device number "," ")[0:2]].append("disconnected at "+z[:15])
			if find_between(s,"device number ","\n") in res:
				del res[find_between(s,"device number ","\n")]
			#print len(s)," mini 2"
	f.close()
	if '' in res:
		del res['']
	initial_key=0;
	for key  in res:
		if(int(key)>initial_key):
			initial_key=int(key)
		print mydict
		mydict={"device_number":key,"mac_address":mac,"username":"akshay","device_type":res[key][3],"connected":"from start"}
		mydict=simplejson.dumps(mydict)
		url='http://'+serveraddress+'/postperipherals'
		r = requests.post(url, data=mydict)
		r.text
		r.status_code
		filein = subprocess.call("rm tmpfile",shell = True)
	#print i," over"
		#time.sleep(1)
	with file("out.txt") as f:
			old = f.read()
	print "done"
	x=[]
	while True:
		with file("out.txt") as f:
			s = f.read()
		olds=s
		s=s.replace(old,"")
		if(s):
			if("new" in s):
				z=s
				s=s[s.find("new"):]
				x.append(["connected at "+z[:15],find_between(s,"Vendor=",","),find_between(s,"idProduct=","\n"),find_between(s,"Product: ","\n"),find_between(s,"New "," found"),find_between(s,"device number "," ")])
				res[find_between(s,"device number "," ")]=["connected at "+z[:15],find_between(s,"Vendor=",","),find_between(s,"idProduct=","\n"),find_between(s,"Product: ","\n"),find_between(s,"New "," found")]
				mydict={"mac_address":mac,"username":user,"device_number":find_between(s,"device number "," "),"connected":z[:15],"device_type":find_between(s,"Product: ","\n")}
				if(int(find_between(s,"device number "," "))>=initial_key):
					#print mydict
					mydict=simplejson.dumps(mydict)
					url='http://'+serveraddress+'/postperipherals'
					r = requests.post(url, data=mydict)
					r.text
					r.status_code
			if("disconnect," in s):
				z=s
				s=s[s.find("disconnect,"):]
				x.append(["disconnected at "+z[:15],find_between(s,"device number ","\n")])
				if find_between(s,"device number ","\n") in res:
					res[find_between(s,"device number ","\n")].append("disconnected at "+z[:15])
					mydict={"mac_address":mac,"username":user,"disconnected":z[:15],"device_number":find_between(s,"device number ","\n")}
					if(int(find_between(s,"device number ","\n"))>=initial_key):
						mydict=simplejson.dumps(mydict)
						url='http://'+serveraddress+'/postperipherals'
						r = requests.post(url, data=mydict)
						r.text
						r.status_code
		f.close()
		old=olds
		time.sleep(2)


